﻿IF OBJECT_ID(N'[__EFMigrationsHistory]') IS NULL
BEGIN
    CREATE TABLE [__EFMigrationsHistory] (
        [MigrationId] nvarchar(150) NOT NULL,
        [ProductVersion] nvarchar(32) NOT NULL,
        CONSTRAINT [PK___EFMigrationsHistory] PRIMARY KEY ([MigrationId])
    );
END;
GO

BEGIN TRANSACTION;
IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261008082711_InitialCreate'
)
BEGIN
    CREATE TABLE [Alerts] (
        [Id] nvarchar(32) NOT NULL,
        [DetectionSource] nvarchar(32) NOT NULL,
        [AttackType] nvarchar(64) NOT NULL,
        [ConfidenceScore] real NULL,
        [SpoofedSource] bit NOT NULL,
        [Description] nvarchar(256) NULL,
        [SourceIp] nvarchar(45) NOT NULL,
        [SourcePort] int NOT NULL,
        [DestinationIp] nvarchar(45) NOT NULL,
        [DestinationPort] int NOT NULL,
        [Protocol] tinyint NOT NULL,
        [SynCount] int NOT NULL,
        [AckCount] int NOT NULL,
        [FinCount] int NOT NULL,
        [RstCount] int NOT NULL,
        [PshCount] int NOT NULL,
        [FlowSnapshotJson] nvarchar(max) NULL,
        [BehaviorSnapshotJson] nvarchar(max) NULL,
        [CreatedAt] datetime2 NOT NULL,
        CONSTRAINT [PK_Alerts] PRIMARY KEY ([Id])
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261008082711_InitialCreate'
)
BEGIN
    CREATE TABLE [AspNetRoles] (
        [Id] nvarchar(450) NOT NULL,
        [Name] nvarchar(256) NULL,
        [NormalizedName] nvarchar(256) NULL,
        [ConcurrencyStamp] nvarchar(max) NULL,
        CONSTRAINT [PK_AspNetRoles] PRIMARY KEY ([Id])
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261008082711_InitialCreate'
)
BEGIN
    CREATE TABLE [AspNetUsers] (
        [Id] nvarchar(450) NOT NULL,
        [MustChangePassword] bit NOT NULL,
        [UserName] nvarchar(256) NULL,
        [NormalizedUserName] nvarchar(256) NULL,
        [Email] nvarchar(256) NULL,
        [NormalizedEmail] nvarchar(256) NULL,
        [EmailConfirmed] bit NOT NULL,
        [PasswordHash] nvarchar(max) NULL,
        [SecurityStamp] nvarchar(max) NULL,
        [ConcurrencyStamp] nvarchar(max) NULL,
        [PhoneNumber] nvarchar(max) NULL,
        [PhoneNumberConfirmed] bit NOT NULL,
        [TwoFactorEnabled] bit NOT NULL,
        [LockoutEnd] datetimeoffset NULL,
        [LockoutEnabled] bit NOT NULL,
        [AccessFailedCount] int NOT NULL,
        CONSTRAINT [PK_AspNetUsers] PRIMARY KEY ([Id])
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261008082711_InitialCreate'
)
BEGIN
    CREATE TABLE [Policies] (
        [Id] nvarchar(32) NOT NULL,
        [UserId] nvarchar(450) NOT NULL,
        [Name] nvarchar(128) NOT NULL,
        [Description] nvarchar(512) NULL,
        [DetectionSource] nvarchar(32) NULL,
        [RfThreshold] real NULL,
        [IfThreshold] real NULL,
        [AttackType] nvarchar(64) NULL,
        [Action] nvarchar(32) NOT NULL,
        [BlockDurationMinutes] int NOT NULL,
        [Priority] int NOT NULL,
        [IsEnabled] bit NOT NULL,
        [CreatedAt] datetime2 NOT NULL,
        [UpdatedAt] datetime2 NOT NULL,
        CONSTRAINT [PK_Policies] PRIMARY KEY ([Id])
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261008082711_InitialCreate'
)
BEGIN
    CREATE TABLE [TrafficRecords] (
        [Id] bigint NOT NULL IDENTITY,
        [AlertId] nvarchar(32) NOT NULL,
        [SourceIp] nvarchar(45) NOT NULL,
        [SourcePort] int NOT NULL,
        [DestinationIp] nvarchar(45) NOT NULL,
        [DestinationPort] int NOT NULL,
        [AttackType] nvarchar(64) NOT NULL,
        [ConfidenceScore] real NULL,
        [Action] nvarchar(32) NOT NULL,
        [Reason] nvarchar(256) NOT NULL,
        [Source] nvarchar(32) NOT NULL,
        [RuleName] nvarchar(128) NULL,
        [Verdict] nvarchar(16) NOT NULL,
        [CreatedAt] datetime2 NOT NULL,
        CONSTRAINT [PK_TrafficRecords] PRIMARY KEY ([Id])
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261008082711_InitialCreate'
)
BEGIN
    CREATE TABLE [UserSettings] (
        [Id] int NOT NULL IDENTITY,
        [DryRun] bit NULL,
        [ModelCombination] nvarchar(64) NULL,
        [CaptureDevice] nvarchar(256) NULL,
        [HeuristicEnabled] bit NULL,
        CONSTRAINT [PK_UserSettings] PRIMARY KEY ([Id])
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261008082711_InitialCreate'
)
BEGIN
    CREATE TABLE [AspNetRoleClaims] (
        [Id] int NOT NULL IDENTITY,
        [RoleId] nvarchar(450) NOT NULL,
        [ClaimType] nvarchar(max) NULL,
        [ClaimValue] nvarchar(max) NULL,
        CONSTRAINT [PK_AspNetRoleClaims] PRIMARY KEY ([Id]),
        CONSTRAINT [FK_AspNetRoleClaims_AspNetRoles_RoleId] FOREIGN KEY ([RoleId]) REFERENCES [AspNetRoles] ([Id]) ON DELETE CASCADE
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261008082711_InitialCreate'
)
BEGIN
    CREATE TABLE [AspNetUserClaims] (
        [Id] int NOT NULL IDENTITY,
        [UserId] nvarchar(450) NOT NULL,
        [ClaimType] nvarchar(max) NULL,
        [ClaimValue] nvarchar(max) NULL,
        CONSTRAINT [PK_AspNetUserClaims] PRIMARY KEY ([Id]),
        CONSTRAINT [FK_AspNetUserClaims_AspNetUsers_UserId] FOREIGN KEY ([UserId]) REFERENCES [AspNetUsers] ([Id]) ON DELETE CASCADE
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261008082711_InitialCreate'
)
BEGIN
    CREATE TABLE [AspNetUserLogins] (
        [LoginProvider] nvarchar(128) NOT NULL,
        [ProviderKey] nvarchar(128) NOT NULL,
        [ProviderDisplayName] nvarchar(max) NULL,
        [UserId] nvarchar(450) NOT NULL,
        CONSTRAINT [PK_AspNetUserLogins] PRIMARY KEY ([LoginProvider], [ProviderKey]),
        CONSTRAINT [FK_AspNetUserLogins_AspNetUsers_UserId] FOREIGN KEY ([UserId]) REFERENCES [AspNetUsers] ([Id]) ON DELETE CASCADE
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261008082711_InitialCreate'
)
BEGIN
    CREATE TABLE [AspNetUserRoles] (
        [UserId] nvarchar(450) NOT NULL,
        [RoleId] nvarchar(450) NOT NULL,
        CONSTRAINT [PK_AspNetUserRoles] PRIMARY KEY ([UserId], [RoleId]),
        CONSTRAINT [FK_AspNetUserRoles_AspNetRoles_RoleId] FOREIGN KEY ([RoleId]) REFERENCES [AspNetRoles] ([Id]) ON DELETE CASCADE,
        CONSTRAINT [FK_AspNetUserRoles_AspNetUsers_UserId] FOREIGN KEY ([UserId]) REFERENCES [AspNetUsers] ([Id]) ON DELETE CASCADE
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261008082711_InitialCreate'
)
BEGIN
    CREATE TABLE [AspNetUserTokens] (
        [UserId] nvarchar(450) NOT NULL,
        [LoginProvider] nvarchar(128) NOT NULL,
        [Name] nvarchar(128) NOT NULL,
        [Value] nvarchar(max) NULL,
        CONSTRAINT [PK_AspNetUserTokens] PRIMARY KEY ([UserId], [LoginProvider], [Name]),
        CONSTRAINT [FK_AspNetUserTokens_AspNetUsers_UserId] FOREIGN KEY ([UserId]) REFERENCES [AspNetUsers] ([Id]) ON DELETE CASCADE
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261008082711_InitialCreate'
)
BEGIN
    CREATE TABLE [Rules] (
        [Id] nvarchar(32) NOT NULL,
        [Name] nvarchar(128) NOT NULL,
        [PolicyId] nvarchar(32) NULL,
        [AlertId] nvarchar(32) NULL,
        [Action] nvarchar(32) NOT NULL,
        [SourceIp] nvarchar(64) NULL,
        [SourcePort] int NULL,
        [DestinationIp] nvarchar(64) NULL,
        [DestinationPort] int NULL,
        [Protocol] tinyint NULL,
        [Status] nvarchar(16) NOT NULL,
        [CreatedAt] datetime2 NOT NULL,
        [UpdatedAt] datetime2 NOT NULL,
        [ExpiresAt] datetime2 NULL,
        CONSTRAINT [PK_Rules] PRIMARY KEY ([Id]),
        CONSTRAINT [FK_Rules_Alerts_AlertId] FOREIGN KEY ([AlertId]) REFERENCES [Alerts] ([Id]) ON DELETE SET NULL,
        CONSTRAINT [FK_Rules_Policies_PolicyId] FOREIGN KEY ([PolicyId]) REFERENCES [Policies] ([Id]) ON DELETE SET NULL
    );
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261008082711_InitialCreate'
)
BEGIN
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'Id', N'Action', N'AttackType', N'BlockDurationMinutes', N'CreatedAt', N'Description', N'DetectionSource', N'IfThreshold', N'IsEnabled', N'Name', N'Priority', N'RfThreshold', N'UpdatedAt', N'UserId') AND [object_id] = OBJECT_ID(N'[Policies]'))
        SET IDENTITY_INSERT [Policies] ON;
    EXEC(N'INSERT INTO [Policies] ([Id], [Action], [AttackType], [BlockDurationMinutes], [CreatedAt], [Description], [DetectionSource], [IfThreshold], [IsEnabled], [Name], [Priority], [RfThreshold], [UpdatedAt], [UserId])
    VALUES (N''P-1'', N''BlockInboundIp'', N''DoS'', 60, ''2026-09-26T00:00:00.0000000'', N''Block the source of any rule-based DoS detection.'', N''HeuristicBased'', NULL, CAST(1 AS bit), N''Heuristic DoS'', 100, NULL, ''2026-09-26T00:00:00.0000000'', N''admin''),
    (N''P-2'', N''BlockInboundIp'', N''PortScan'', 30, ''2026-09-26T00:00:00.0000000'', N''Block the scanning source of a Random Forest port scan detection (reconnaissance: short block).'', N''RandomForest'', NULL, CAST(1 AS bit), N''Random Forest PortScan'', 90, CAST(0.7 AS real), ''2026-09-26T00:00:00.0000000'', N''admin''),
    (N''P-3'', N''BlockInboundIp'', N''BruteForce'', 120, ''2026-09-26T00:00:00.0000000'', N''Block the source of a Random Forest brute force detection (credential attack: long block).'', N''RandomForest'', NULL, CAST(1 AS bit), N''Random Forest BruteForce'', 90, CAST(0.7 AS real), ''2026-09-26T00:00:00.0000000'', N''admin''),
    (N''P-4'', N''BlockInboundIp'', N''PortScan'', 30, ''2026-09-26T00:00:00.0000000'', N''Block the scanning source of any rule-based port scan detection (reconnaissance: short block).'', N''HeuristicBased'', NULL, CAST(1 AS bit), N''Heuristic PortScan'', 100, NULL, ''2026-09-26T00:00:00.0000000'', N''admin''),
    (N''P-5'', N''BlockInboundIp'', N''BruteForce'', 120, ''2026-09-26T00:00:00.0000000'', N''Block the source of any rule-based brute force detection (credential attack: long block).'', N''HeuristicBased'', NULL, CAST(1 AS bit), N''Heuristic BruteForce'', 100, NULL, ''2026-09-26T00:00:00.0000000'', N''admin''),
    (N''P-6'', N''Monitor'', N''Unknown_Anomaly'', 0, ''2026-09-26T00:00:00.0000000'', N''Surface an unnamed Isolation Forest anomaly for review. Monitor-only: an unnamed anomaly is suspicious, not a confirmed attack.'', N''IsolationForest'', CAST(0.7 AS real), CAST(1 AS bit), N''Isolation Forest anomaly'', 90, NULL, ''2026-09-26T00:00:00.0000000'', N''admin''),
    (N''P-7'', N''BlockInboundIp'', N''DoS'', 60, ''2026-09-26T00:00:00.0000000'', N''Block the source of a Random Forest DoS detection (availability attack).'', N''RandomForest'', NULL, CAST(1 AS bit), N''Random Forest DoS'', 90, CAST(0.7 AS real), ''2026-09-26T00:00:00.0000000'', N''admin'')');
    IF EXISTS (SELECT * FROM [sys].[identity_columns] WHERE [name] IN (N'Id', N'Action', N'AttackType', N'BlockDurationMinutes', N'CreatedAt', N'Description', N'DetectionSource', N'IfThreshold', N'IsEnabled', N'Name', N'Priority', N'RfThreshold', N'UpdatedAt', N'UserId') AND [object_id] = OBJECT_ID(N'[Policies]'))
        SET IDENTITY_INSERT [Policies] OFF;
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261008082711_InitialCreate'
)
BEGIN
    CREATE INDEX [IX_Alerts_CreatedAt] ON [Alerts] ([CreatedAt]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261008082711_InitialCreate'
)
BEGIN
    CREATE INDEX [IX_Alerts_SourceIp] ON [Alerts] ([SourceIp]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261008082711_InitialCreate'
)
BEGIN
    CREATE INDEX [IX_AspNetRoleClaims_RoleId] ON [AspNetRoleClaims] ([RoleId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261008082711_InitialCreate'
)
BEGIN
    EXEC(N'CREATE UNIQUE INDEX [RoleNameIndex] ON [AspNetRoles] ([NormalizedName]) WHERE [NormalizedName] IS NOT NULL');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261008082711_InitialCreate'
)
BEGIN
    CREATE INDEX [IX_AspNetUserClaims_UserId] ON [AspNetUserClaims] ([UserId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261008082711_InitialCreate'
)
BEGIN
    CREATE INDEX [IX_AspNetUserLogins_UserId] ON [AspNetUserLogins] ([UserId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261008082711_InitialCreate'
)
BEGIN
    CREATE INDEX [IX_AspNetUserRoles_RoleId] ON [AspNetUserRoles] ([RoleId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261008082711_InitialCreate'
)
BEGIN
    CREATE INDEX [EmailIndex] ON [AspNetUsers] ([NormalizedEmail]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261008082711_InitialCreate'
)
BEGIN
    EXEC(N'CREATE UNIQUE INDEX [UserNameIndex] ON [AspNetUsers] ([NormalizedUserName]) WHERE [NormalizedUserName] IS NOT NULL');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261008082711_InitialCreate'
)
BEGIN
    CREATE INDEX [IX_Rules_AlertId] ON [Rules] ([AlertId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261008082711_InitialCreate'
)
BEGIN
    CREATE INDEX [IX_Rules_PolicyId] ON [Rules] ([PolicyId]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261008082711_InitialCreate'
)
BEGIN
    CREATE INDEX [IX_TrafficRecords_CreatedAt] ON [TrafficRecords] ([CreatedAt]);
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261008082711_InitialCreate'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20261008082711_InitialCreate', N'10.0.11');
END;

COMMIT;
GO

BEGIN TRANSACTION;
IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261016101627_LowerSeededAiPolicyThresholds'
)
BEGIN
    EXEC(N'UPDATE [Policies] SET [RfThreshold] = CAST(0.5 AS real)
    WHERE [Id] = N''P-2'';
    SELECT @@ROWCOUNT');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261016101627_LowerSeededAiPolicyThresholds'
)
BEGIN
    EXEC(N'UPDATE [Policies] SET [RfThreshold] = CAST(0.5 AS real)
    WHERE [Id] = N''P-3'';
    SELECT @@ROWCOUNT');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261016101627_LowerSeededAiPolicyThresholds'
)
BEGIN
    EXEC(N'UPDATE [Policies] SET [IfThreshold] = CAST(0.5 AS real)
    WHERE [Id] = N''P-6'';
    SELECT @@ROWCOUNT');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261016101627_LowerSeededAiPolicyThresholds'
)
BEGIN
    EXEC(N'UPDATE [Policies] SET [RfThreshold] = CAST(0.5 AS real)
    WHERE [Id] = N''P-7'';
    SELECT @@ROWCOUNT');
END;

IF NOT EXISTS (
    SELECT * FROM [__EFMigrationsHistory]
    WHERE [MigrationId] = N'20261016101627_LowerSeededAiPolicyThresholds'
)
BEGIN
    INSERT INTO [__EFMigrationsHistory] ([MigrationId], [ProductVersion])
    VALUES (N'20261016101627_LowerSeededAiPolicyThresholds', N'10.0.11');
END;

COMMIT;
GO

